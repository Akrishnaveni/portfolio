import React from 'react';
import { Code, Server, Database } from 'lucide-react';

const skills = [
  {
    icon: <Code className="w-6 h-6" />,
    title: 'Frontend Development',
    description: 'Creating responsive and intuitive user interfaces',
    items: ['React', 'TypeScript', 'Tailwind CSS', 'Next.js']
  },
  {
    icon: <Server className="w-6 h-6" />,
    title: 'Backend Development',
    description: 'Building robust server-side applications',
    items: ['Node.js', 'Express', 'Python', 'Java']
  },
  {
    icon: <Database className="w-6 h-6" />,
    title: 'Database & DevOps',
    description: 'Managing data and deployment infrastructure',
    items: ['MongoDB', 'PostgreSQL', 'Docker', 'AWS']
  }
];

export default function About() {
  return (
    <section id="about" className="py-20">
      <div className="container mx-auto px-6">
        <div className="max-w-4xl mx-auto">
          <h2 className="text-3xl md:text-4xl font-bold text-center text-gray-900 dark:text-white mb-16">
            About Me
          </h2>
          
          <div className="mb-16">
            <p className="text-lg text-gray-600 dark:text-gray-300 leading-relaxed mb-6">
              I'm a dedicated full-stack developer with expertise in both frontend and backend technologies. My journey in software development has been driven by a passion for creating efficient, scalable, and user-friendly applications that solve real-world problems.
            </p>
            <p className="text-lg text-gray-600 dark:text-gray-300 leading-relaxed">
              With a strong foundation in computer science and years of hands-on experience, I specialize in building full-stack web applications using modern technologies and best practices.
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            {skills.map((skill, index) => (
              <div
                key={index}
                className="p-6 bg-white dark:bg-gray-900 rounded-xl shadow-lg hover:shadow-xl transition-shadow"
              >
                <div className="w-12 h-12 bg-blue-100 dark:bg-blue-900 rounded-lg flex items-center justify-center text-blue-600 dark:text-blue-400 mb-4">
                  {skill.icon}
                </div>
                <h3 className="text-xl font-semibold text-gray-900 dark:text-white mb-2">
                  {skill.title}
                </h3>
                <p className="text-gray-600 dark:text-gray-300 mb-4">
                  {skill.description}
                </p>
                <ul className="space-y-2">
                  {skill.items.map((item, itemIndex) => (
                    <li
                      key={itemIndex}
                      className="text-gray-600 dark:text-gray-300 flex items-center"
                    >
                      <span className="w-1.5 h-1.5 bg-blue-600 dark:bg-blue-400 rounded-full mr-2"></span>
                      {item}
                    </li>
                  ))}
                </ul>
              </div>
            ))}
          </div>
        </div>
      </div>
    </section>
  );
}