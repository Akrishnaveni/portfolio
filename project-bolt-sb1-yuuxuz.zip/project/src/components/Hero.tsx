import React from 'react';
import { ArrowRight } from 'lucide-react';

export default function Hero() {
  return (
    <section id="home" className="min-h-screen flex items-center justify-center pt-20">
      <div className="container mx-auto px-6">
        <div className="max-w-4xl mx-auto flex flex-col md:flex-row items-center gap-12">
          <div className="md:w-1/2 text-center md:text-left">
            <h1 className="text-4xl md:text-6xl font-bold text-gray-900 dark:text-white mb-6">
              Hi, I'm Krishnaveni
              <span className="text-blue-600 dark:text-blue-400"> Full Stack Developer</span>
            </h1>
            <p className="text-xl text-gray-600 dark:text-gray-300 mb-12 leading-relaxed">
              Passionate about creating elegant solutions through code and design. Specialized in building scalable web applications with modern technologies.
            </p>
            <div className="flex flex-col sm:flex-row items-center justify-center md:justify-start gap-4">
              <a
                href="#work"
                className="group flex items-center gap-2 px-8 py-4 bg-blue-600 text-white rounded-full hover:bg-blue-700 transition-colors"
              >
                View My Work
                <ArrowRight className="w-5 h-5 group-hover:translate-x-1 transition-transform" />
              </a>
              <a
                href="#contact"
                className="px-8 py-4 border-2 border-gray-300 dark:border-gray-700 text-gray-700 dark:text-gray-300 rounded-full hover:border-blue-600 hover:text-blue-600 dark:hover:border-blue-400 dark:hover:text-blue-400 transition-colors"
              >
                Get in Touch
              </a>
            </div>
          </div>
          <div className="md:w-1/2 flex justify-center">
            <div className="relative w-64 h-64">
              <img
                src="https://res.cloudinary.com/dqupljwh9/image/upload/v1731575926/krishnaveni_youfvv.png?auto=format&fit=crop&q=80&w=1000"
                alt="Krishnaveni Anna - Full Stack Developer"
                className="rounded-full object-cover w-full h-full shadow-lg"
              />
              <div className="absolute inset-0 rounded-full border-4 border-blue-600 dark:border-blue-400 opacity-50"></div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}